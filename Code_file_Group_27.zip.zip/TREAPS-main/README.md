# TREAPS
Here in this project, We have implemented a full fledged dictionary using Treaps Data structure.
Here we have used random function to assign priorities to the nodes.
Our dictionary supports the following functions -:

1> INSERTION - just end a word with its meaning and it will be inserted in dictionary

2> DELETION - it will delete the word from dictionary if that word exists.

3> SEARCH - just enter the word and it will print the meaning of that word if it exists.

4> View - it will print the whole dictionary in output

5> Update - it will help to change the meaning of already existing word

6> Exit - it will exit the program.
